<?php 
header("location:view");
?>

</body>
</html>