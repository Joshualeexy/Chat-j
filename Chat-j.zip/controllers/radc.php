<?php  
echo uniqid();
?>