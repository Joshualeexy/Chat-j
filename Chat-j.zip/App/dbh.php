<?php

$con = mysqli_connect("localhost","root","","cat-j");
if (!$con) {
echo"could not onnect";

}

?>