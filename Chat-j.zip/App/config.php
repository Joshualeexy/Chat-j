<?php
session_start();
define("APP_NAME", "CHAT-J");
define('APP_URL', 'http://localhost/Chat-j/');
error_reporting(0);
