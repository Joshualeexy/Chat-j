
</body>
    <footer>
        <script src="asset/js/script.js"></script>
    </footer>
</html>