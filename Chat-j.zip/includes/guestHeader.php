<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="<?= APP_URL ?>asset/js/jquery.js"></script>
    <link rel="stylesheet" href="<?= APP_URL ?>asset/css/main.css">
    <link rel="stylesheet" href="<?= APP_URL ?>asset/css/bootstrap.css">
    <link rel="stylesheet" href="<?= APP_URL ?>asset/css/all.css">
    <title><?= $title ?></title>
</head>
<body>

